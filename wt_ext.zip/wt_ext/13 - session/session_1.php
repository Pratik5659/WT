<?php
    session_start();

    if (isset($_POST["btn_submit"]))
    {
        $value = $_POST["txt_fullname"];
        $_SESSION["fname"] = $value;
        header("Location:session_2.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>page 1</title>
</head>
<body>
    <form action="session_1.php" method="POST">
        <input type="text" name = "txt_fullname">
        <input type="submit" name="btn_submit">
    </form>
</body>
</html>