<?php
$conn = mysqli_connect("localhost","root","","db");

if($conn)
{
    echo"Database Connected";
}
else
{
    echo "Database Not Connected";
}

?>