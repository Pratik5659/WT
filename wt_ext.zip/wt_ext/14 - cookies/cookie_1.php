<?php
if (isset($_POST["btn_submit"])) 
{
     $value = $_POST["txt_fullname"];
     setcookie("user-name", $value, time()+1 *60*60);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page 1</title>
</head>
<body>
    <form action="cookie_1.php" method="POST">
        <input type="text" name = "txt_fullname">
        <input type="submit" name="btn_submit">
    </form>
</body>
</html>