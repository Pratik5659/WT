<?php
echo"<h2> Function <h2>";

function Multiply()
{
    $a=10;
    $b=5;

    echo"a:-".$a;
    echo"<br>b:-".$b;

    echo"<br>Multiplication = ".$a*$b;
}
//Function call without parameters
Multiply();

    echo"<br>-----------------------------------------";

echo"<h2> <b>With Parameters</b> <h2>";
function pMultiply($a,$b)
{

    echo"Multiplication =".$a*$b;

}
pMultiply(2,5);


echo"<br>-----------------------------------------";