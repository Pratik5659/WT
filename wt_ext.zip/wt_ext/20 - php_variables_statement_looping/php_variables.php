<?php
$a = "om";
$b = 07;
$a = 8.2002;

echo "a=".$a;
echo "b=".$b;
echo "c=".$c;
?>
