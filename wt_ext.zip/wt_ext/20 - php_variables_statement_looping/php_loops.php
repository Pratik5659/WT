<!-- while -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Looping In PHP</title>
</head>
<body>
    <?php
        echo"<h2> Find Only Even Numbers from 1-20 </h2>";

        $i = 1;
        echo"EVEN NUMBERS:";
        while($i<=20)
        {
            if($i%2==0)
            {
                
                echo "<br>".$i;
            }
            $i++;

        }
    ?>
</body>
</html>

<!-- do while -->

<?php
$x = 1;

do {
  echo "The number is: $x <br>";
  $x++;
} while ($x <= 5);
?>


<!-- for -->
<?php
for ($x = 0; $x <= 10; $x++) {
  echo "The number is: $x <br>";
}
?>

<!-- for each -->
<?php
$colors = array("red", "green", "blue", "yellow");

foreach ($colors as $value) {
  echo "$value <br>";
}
?>
