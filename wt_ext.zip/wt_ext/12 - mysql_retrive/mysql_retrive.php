<?php
$conn=mysqli_connect("localhost","root","","db");


if(isset($_GET["btn_delete"]))
{
  $sql="delete from register where rid='".$_GET["rid"]."'";
  if(mysqli_query($conn,$sql))
  {
    echo "Records Deleted Successfully";
  }
  else
  {
   echo "Records Not Deleted";
}

}

?>

<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body>



<table id="customers">
  <tr>
    <th>Roll NO.</th>
    <th>Full Name</th>
    <th>Address</th>
    <th>Contact</th>
    <th>Email</th>
    <th>User-Name</th>
    <th>Password</th>
    <th>Action</th>
  </tr>
  <?php
    $sql="select * from register";
    $result=mysqli_query($conn,$sql);
    while($data=mysqli_fetch_array($result))
    {
        echo "
        <form action='mysql_retrive.php' method='GET'>
        <tr>
          <input type='hidden' name='rid' value=".$data['rid'].">
    <td>".$data["rid"]."</td>
    <td>".$data["full_name"]."</td>
    <td>".$data["address"]."</td>
    <td>".$data["contact"]."</td>
    <td>".$data["email"]."</td>
    <td>".$data["username"]."</td>
    <td>".$data["pass"]."</td>
    <td>
      <input type='submit' name='btn_delete' value='Delete'>
    </td>
  </tr>

</form>
        ";
    }


  ?>
  
  
</table>

</body>
</html>


