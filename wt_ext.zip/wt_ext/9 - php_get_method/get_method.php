<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="getmethod.php" method="GET">
        Name: <input type="text" name="name">
        </br></br>
        Email: <input type="text" name="email">
        </br></br>
        <input type="submit">
    </form>
</body>
</html>

<?php
    $name = $_GET["name"];
    $email = $_GET["email"];

    echo"</br> </br>Welcome ". $name .", this is your email '". $email." '";
?>
