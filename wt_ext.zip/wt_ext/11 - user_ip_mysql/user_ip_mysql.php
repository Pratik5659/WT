<?php
$conn=mysqli_connect("localhost","root","","db");

if (isset($_GET["btn_register"]))
{
	$query="insert into register(full_name,address,contact,email,username,pass) values('".$_GET["txt_fullname"]."','".$_GET["txt_address"]."','".$_GET["txt_contact"]."','".$_GET["txt_email"]."','".$_GET["txt_username"]."','".$_GET["txt_password"]."')";

    if(mysqli_query($conn,$query))
    {
        echo "Registered Successfully";
    }
    else
    {
        echo "Not Registered";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <style type="text/css">
		body
		{
			background: #d53369;  
            background: -webkit-linear-gradient(to right, #cbad6d, #d53369);  
            background: linear-gradient(to right, #cbad6d, #d53369); 

		}
		.divCenter
		{
			width: 35%;
			height: 550px;
			background-color: white;
			margin:auto auto auto auto;
			margin-top: 50px;
			border-radius: 10px;
			padding-top: 10px;
			padding-left: 20px;
			padding-right: 20px;
		}
		.h1_style
		{
			text-align: center;
			margin-top: 20px;
		}
		input[type="text"],input[type="email"],input[type="password"]
		{
			width: 90%;
			height: 25px;
			margin-bottom: 15px;
		}
		textarea
		{
			width: 90%;
		}
	</style>
</head>
<body>
    <form action="user_ip_mysql.php" method="GET">
    <div class="divCenter">
		<h2 class="h1_style">Register Here</h2>
		<hr/>
		<label>Full Name</label><br/>
		<input type="text" name="txt_fullname" placeholder="Enter Full Name" required/>
		<br/>
		<label>Address</label><br/>
		<textarea name="txt_address" rows="3" ></textarea>
		<br/>
		<label>Contact</label><br/>
		<input type="text" name="txt_contact" placeholder="Enter Contact No." required/>
		<br/>

		<label>Email</label><br/>
		<input type="email" name="txt_email" placeholder="Enter Email" required/>
		<br/>

		<label>User-Name</label><br/>
		<input type="text" name="txt_username" placeholder="Enter User-Name" required/>
		<br/>

		<label>Password</label><br/>
		<input type="password" name="txt_password" placeholder="Enter Password" required/>
		<br/>

		<input type="submit" name="btn_register" value="Register">
	</div>
    </form>
</body>
</html>